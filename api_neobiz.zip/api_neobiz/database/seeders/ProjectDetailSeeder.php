<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Project;
use App\Models\ProjectDetail;

class ProjectDetailSeeder extends Seeder
{
    public function run()
    {
        //
    }
}
