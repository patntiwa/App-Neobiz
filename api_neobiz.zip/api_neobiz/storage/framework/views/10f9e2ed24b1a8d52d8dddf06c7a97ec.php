<?php echo e($slot); ?>

<?php /**PATH /home/lpdev/Documents/App-Neobiz /api_neobiz/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>